const bcryptjs = require('bcryptjs');

const Veterinario = require('../models/veterinario');
const generarId = require('../helpers/generarId');

// PETICIONES HTTP

const registrar = async (req, res) => {

    const { nombre, correo, password } = req.body;
    const veterinario = new Veterinario({ nombre, correo, password })

    // Prevenir usuarios duplicados
    const existeUsuario = await Veterinario.findOne({ correo });

    if (existeUsuario) {
        const error = new Error('Usuario ya registrado');
        return res.status(400).json({ // Para deterner la ejecucion de la aplicación 
            msg: error.message // para mostrar el error creado arriba
        })
    }

    // Encriptar contraseña
    const salt = bcryptjs.genSaltSync();
    veterinario.password = bcryptjs.hashSync(password, salt);

    try {
        //Guardar un nuevo Veterinario
        const veterinarioGuardado = await veterinario.save();

        res.status(200).json({
            msg: 'Registrando usuario...',
            veterinarioGuardado,
        })


    } catch (error) {
        console.log(error)
    }
}

// Confirmar Cuenta
const confirmar = async (req, res) => {

    const { token } = req.params;

    const usuarioConfirmar = await Veterinario.findOne({ token });

    if (!usuarioConfirmar) {
        const error = new Error('Token no válido');
        return res.status(404).json({
            msg: error.message
        });
    }

    try {

        usuarioConfirmar.token = null;
        usuarioConfirmar.confirmado = true;
        await usuarioConfirmar.save();

        res.status(200).json({
            msg: 'Usuario confirmado correctamente'
        })
    } catch (error) {
        console.log(error)
    }
}

// Obtener perfil autenticado
const perfil = (req, res) => {

    const { veterinario } = req

    res.status(200).json({
        perfil: veterinario
    });
}

// Resetear Password

const olvidePassword = async (req, res) => {
    const { correo } = req.body

    const existeVeterinario = await Veterinario.findOne({ correo });
    if (!existeVeterinario) {
        const error = new Error('El usuario no existe');
        return res.status(400).json({ msg: error.message });
    }

    try {
        existeVeterinario.token = generarId();
        await existeVeterinario.save();
        res.json({ msg: 'Hemos enviado un correo con las instrucciones' })
    } catch (error) {
        console.log(error)
    }

}

const comprobarToken = async (req, res) => {
    const { token } = req.params

    const tokenValido = await Veterinario.findOne({ token });

    if (tokenValido) {
        //El token es válido el usuario existe
        res.json({ msg: 'Token válido y el usuario existe' });
    } else {
        const error = new Error('Token no válido');
        return res.status(400).json({
            msg: error.message
        })
    }
}

const nuevoPassword = async (req, res) => {
    const { token } = req.params;
    const { password } = req.body;

    const veterinario = await Veterinario.findOne({ token });
    if (!veterinario) {
        const error = new Error('Hubo un error');
        return res.status(400).json({ msg: error.message });
    }

    try {
        veterinario.token = null;
        veterinario.password = password;

        //Encriptar la contraseña
        const salt = bcryptjs.genSaltSync();
        veterinario.password = bcryptjs.hashSync(password, salt);

        // Guardar los cambios
        await veterinario.save();
        res.status(200).json({
            msg: 'Password modificado correctamente'
        })

    } catch (error) {
        console.log(error)
    }
}


module.exports = {
    registrar,
    perfil,
    confirmar,
    olvidePassword,
    comprobarToken,
    nuevoPassword
}

// Importante, el try catch se utiliza cuando hay que cambiar algo en la BD
