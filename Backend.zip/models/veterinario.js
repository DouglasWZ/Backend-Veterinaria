const { Schema, model } = require('mongoose');
const generarId = require('../helpers/generarId');


const VeterinarioSchema = Schema({
    nombre: {
        type: String,
        required: [true, 'El nombre es obligatorio'],
        trim: true // para eliminar los espacios en blanco tanto al inicio, como al final
    },
    correo: {
        type: String,
        required: [true, 'El correo es obligatorio'],
        unique: true // para poder validar mas adelante que el correo no sea duplicado y sea unico 
    },
    password: {
        type: String,
        required: [true, 'La contraseña es obligatoria']
    },
    telefono: {
        type: String,
        default: null,
        trim: true
    },
    web: {
        type: String,
        default: null
    },
    token: {
        type: String,
        default: generarId
    },
    confirmado: { // para validar que su cuenta esta confirmada. se le enviara un correo para validarlo, y en caso de estar validado se cambiara su estado a true
        type: Boolean,
        default: false
    }
});

module.exports = model('Veterinario', VeterinarioSchema);